#include "ros/ros.h"
#include "practice/my_property.h"

int main(int argc, char **argv)
{
  ros::init(argc, argv, "property_talker");
  ros::NodeHandle n;
  ros::Publisher pub = n.advertise<practice::my_property>("property", 1000);
  ros::Rate loop_rate(10);

  while (ros::ok())
  {
    practice::my_property msg;
    msg.name = "example_name";
    msg.Class = 1;

    ROS_INFO("Publishing: name = %s, class = %d", msg.name.c_str(), msg.Class);
    pub.publish(msg);
    ros::spinOnce();
    loop_rate.sleep();
  }

  return 0;
}